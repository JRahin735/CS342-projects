// @authors: Rahin Jain (665219123), Aarav Surkatha (667714562)

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Iterator;

public abstract class DictionaryTest {
    public abstract ProjOneDictionary<Integer,String> newDictionary();

    @Test
    public void testSize() {
        ProjOneDictionary<Integer, String> dict = newDictionary();
        assertEquals(0,dict.getSize());
    }

    @Test
    public void testNullValue() {
        ProjOneDictionary<Integer, String> dict = newDictionary();
        try{
            dict.insert(0,null);
            fail();
        } catch (NullValueException e){
            return;
        }
    }

    @Test
    public void testInsert() throws NullValueException {
        ProjOneDictionary<Integer, String> dict = newDictionary();

        assertTrue(dict.insert(1, "One"));
        assertTrue(dict.insert(2, "Two"));
        assertFalse(dict.insert(1, "New One")); // Key already exists
        assertFalse(dict.insert(null, "Null")); // Null key
        try {
            dict.insert(3, null); // Null value
        }
        catch (Exception e) {

        }
    }

    @Test
    public void testFind() throws NullValueException {
        ProjOneDictionary<Integer, String> dict = newDictionary();

        dict.insert(1, "One");
        dict.insert(2, "Two");
        assertEquals("One", dict.find(1));
        assertEquals("Two", dict.find(2));
        assertNull(dict.find(3)); // Key does not exist
    }

    @Test
    public void testDelete() throws NullValueException {
        ProjOneDictionary<Integer, String> dict = newDictionary();

        dict.insert(1, "One");
        dict.insert(2, "Two");
        assertTrue(dict.delete(1));
        assertNull(dict.find(1)); // Key should not exist after deletion
        assertFalse(dict.delete(3)); // Key does not exist
        assertFalse(dict.delete(null)); // Null key
    }

    @Test
    public void testIterator() throws NullValueException {
        ProjOneDictionary<Integer, String> dict = newDictionary();

        dict.insert(2, "Two");
        dict.insert(1, "One");
        dict.insert(3, "Three");

        Iterator<Integer> iterator = dict.iterator();
        assertTrue(iterator.hasNext());
        assertEquals(1, iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals(2, iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals(3, iterator.next());
        assertFalse(iterator.hasNext());
    }

    @Test
    public void testGetSize() throws NullValueException {
        ProjOneDictionary<Integer, String> dict = newDictionary();

        assertEquals(0, dict.getSize());
        dict.insert(1, "One");
        assertEquals(1, dict.getSize());
        dict.insert(2, "Two");
        assertEquals(2, dict.getSize());
        dict.delete(1);
        assertEquals(1, dict.getSize());
    }
}
