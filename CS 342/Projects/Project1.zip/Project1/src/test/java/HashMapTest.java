// @authors: Rahin Jain (665219123), Aarav Surkatha (667714562)

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class HashMapTest
{
    private HashMapDict<Integer, Integer> hashMapDict;

    @BeforeEach
    public void setUp()
    {
        hashMapDict = new HashMapDict<>();
    }

    @Test
    public void testResize() throws NullValueException
    {
        // Insert 50 elements into the hash table
        for (int i = 0; i < 50; i++)
        {
            hashMapDict.insert(i, i);
        }

        // Check the size after insertion
        assertEquals(50, hashMapDict.getSize());
    }
}
