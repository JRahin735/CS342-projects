// @authors: Rahin Jain (665219123), Aarav Surkatha (667714562)

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Iterator;

// No test cases needed specifically for the BST implementation.

public class BSTTest {


}
