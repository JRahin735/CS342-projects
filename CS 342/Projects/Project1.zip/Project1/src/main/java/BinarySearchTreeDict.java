// @authors: Rahin Jain (665219123), Aarav Surkatha (667714562)

import java.security.Key;
import java.util.Iterator;

public class BinarySearchTreeDict <K extends Comparable<K>,V> implements ProjOneDictionary<K,V> {

    private Node root;
    private int size;

    public BinarySearchTreeDict()
    {
        this.root = null;
        this.size = 0;
    }
    private class Node
    {
        private K key;
        private V value;

        private int size;
        private Node left,right;

        public Node(K key, V value) {
            this.key = key;
            this.value = value;
            this.left = null;
            this.right = null;
        }
    }

    private class BSTIterator implements Iterator<K>
    {
        private Node nextNode;

        public BSTIterator()
        {
            nextNode = findLowestNode(root);
        }

        @Override
        public boolean hasNext()
        {
            return nextNode != null;
        }

        @Override
        public K next()
        {
            if (!hasNext())
            {
                return null;
            }
            Node current = nextNode;
            nextNode = findSuccessor(nextNode);
            return current.key;
        }

        private Node findSuccessor(Node node)
        {
            if (node.right != null)
            {
                return findLowestNode(node.right);
            }
            Node successor = null;
            Node ancestor = root;
            while (ancestor != node)
            {
                if (node.key.compareTo(ancestor.key) < 0)
                {
                    successor = ancestor;
                    ancestor = ancestor.left;
                }
                else
                {
                    ancestor = ancestor.right;
                }
            }
            return successor;
        }

        private Node findLowestNode(Node node)
        {
            while (node != null && node.left != null)
            {
                node = node.left;
            }
            return node;
        }
    }

        @Override
    public boolean insert(K key, V value) throws NullValueException
    {
        if (key == null)
        {
            return false;
        }
        if(value == null)
        {
            // Value is null
            throw new NullValueException();
        }
        if (find(key) != null)
        {
            // Key exists, value changed
            root = InsertRec(root,key,value);
            size++;
            return false;
        }
        else
        {
            // Key does not exist
            root = InsertRec(root,key,value);
            size++;
            return true;
        }
    }
    private Node InsertRec(Node root, K key, V value)
    {
        if (root == null)
        {
            return new Node(key, value);
        }
        int cmp = key.compareTo(root.key);
        if (cmp < 0)
        {
            root.left = InsertRec(root.left, key, value);
        }
        else if (cmp > 0)
        {
            root.right = InsertRec(root.right, key, value);
        }
        else
        {
            root.value = value; // Update value if key already exists
        }
        return root;
    }

    @Override
    public V find(K key)
    {
        return FindRec(root,key);
    }
    private V FindRec(Node root, K key)
    {
        if (root == null)
        {
            return null;
        }
        int cmp = key.compareTo(root.key);

        if (cmp < 0)
        {
            return FindRec(root.left, key);
        }
        else if (cmp > 0)
        {
            return FindRec(root.right, key);
        }
        else
        {
            return root.value;
        }
    }
    @Override
    public boolean delete(K key) {

        if (root == null || key == null)
        {
            return false;
        }
        else if (find(key) == null)
        {
            return false;
        }
        else
        {
            root = DeleteRec(root, key);
            size--;
            return true;
        }
    }
    private Node DeleteRec(Node root, K key)
    {
        if (root == null)
        {
            return null;
        }
        int cmp = key.compareTo(root.key);
        if (cmp < 0)
        {
            root.left = DeleteRec(root.left, key);
        }
        else if (cmp > 0)
        {
            root.right = DeleteRec(root.right, key);
        } else
        {
            // Case 1: No child or one child
            if (root.left == null)
            {
                return root.right;
            }
            else if (root.right == null)
            {
                return root.left;
            }
            // Case 2: Two children
            Node successor = FindLowest(root.right);
            root.key = successor.key;
            root.value = successor.value;
            root.right = DeleteRec(root.right, successor.key);
        }
        return root;
    }

    // DeleteRec helper function
    private Node FindLowest(Node root)
    {
        while (root.left != null)
        {
            root = root.left;
        }
        return root;
    }
    @Override
    public int getSize()
    {
        return size;
    }

    @Override
    public Iterator<K> iterator()
    {
        return new BSTIterator();
    }
}