// @authors: Rahin Jain (665219123), Aarav Surkatha (667714562)

public class NullValueException extends Exception{
    @Override
    public String getMessage(){
        return "Value cannot be null";
    }
}
