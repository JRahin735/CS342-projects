// @authors: Rahin Jain (665219123), Aarav Surkatha (667714562)

import java.util.Iterator;
import java.util.NoSuchElementException;

public class HashMapDict<K,V> implements ProjOneDictionary<K,V> {


    private static final int CAPACITY = 10;
    private Object[] table;
    private int size;

    // Constructor
    public HashMapDict()
    {
        this.table = new Object[CAPACITY];
        this.size = 0;
    }

    @Override
    public boolean insert(K key, V value) throws NullValueException
    {
        // if value is null
        if (value == null) {
            // value is null :/
            throw new NullValueException();
        }

        // resize if half of table is full
        if ((double) size / table.length >= 0.5) {
            // doubles the size of table when needed
            resize();
        }

        int keyIndex = findIndex(key, table);

        if (keyIndex == -1)
        {
            // key doesn't exist in table, hence add a new entry in the table
            int IndexToInsertIn = (key.hashCode()) % table.length;

            while (((Entry<K,V>)table[IndexToInsertIn]) != null)
            {
                IndexToInsertIn++;
            }
            Entry<K, V> e = new Entry<>(key, value);
            table[IndexToInsertIn] = e;
            size++;
            return false;
        }
        else {
            // key exists in table and keyEntry knows where the key is
            Entry<K, V> e = (Entry<K, V>)table[keyIndex]; // shallow copy
            e.value = value; // replaces the old value stored in e to new value from argument
            return true;
        }
    }

    private void resize()
    {
        int newCapacity = table.length * 2;
        Object[] newTable = new Object[newCapacity];

        // Rehash all entries into the new table
        for (Object entry : table)
        {
            if (entry != null)
            {
                Entry<K, V> e = (Entry<K, V>) entry;

                int newIndex = (((Entry<K, V>) entry).key.hashCode()) % table.length;
                // linear probing
                while (newTable[newIndex] != null)
                {
                    newIndex = newIndex+1;
                }
                newTable[newIndex] = e;
            }
        }
        table = newTable;
    }

    private int findIndex(K key, Object[] tableToFindIn)
    {
        int index = (key.hashCode()) % tableToFindIn.length;

        // linear search to find key in table
        while (tableToFindIn[index] != null)
        {
            Entry<K, V> e = (Entry<K, V>) table[index];
                if (e != null)
                {
                    if (e.key == key)
                    {
                        return index;
                    }
                }
            index = (index + 1) % tableToFindIn.length; // Linear probing
        }
        // key not found
        return -1;
    }

    @Override
    public V find(K key)
    {
        int index = findIndex(key, table);
        if (index == -1)
        {
            return null;
        }
        else
        {
            while (table[index] != null)
            {
                Entry <K, V> e = (Entry<K, V>) table[index];
                    if (e.key == key)
                    {
                        return e.value;
                    }
                index = (index + 1) % table.length;
            }
            return null;
        }
    }

    @Override
    public boolean delete(K key)
    {
        int index = findIndex(key, table);
        if (index == -1)
        {
            return false;
        }
        else
        {
            while (table[index] != null)
            {
                if (((Entry<K, V>) table[index]).key == key)
                {
                    table[index] = null;
                    size--;
                    return true;
                }
                index = (index + 1) % table.length;
            }
            return false;
        }
    }

    @Override
    public int getSize()
    {
        return size;
    }

    private class HashMapIterator implements Iterator<K>
    {
        private int curr = -1;
        private int remainEles = size;

        HashMapIterator() {
            // Find the first non-null element to start iterating from
            for (int i = 0; i < table.length; i++) {
                if (table[i] != null) {
                    curr = i;
                    break;
                }
            }
        }

        @Override
        public boolean hasNext() {
            return remainEles > 0;
        }

        @Override
        public K next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }

            K key = ((Entry<K, V>) table[curr]).key;

            // Move to the next non-null element
            do {
                curr++;
            } while (curr < table.length && table[curr] == null);

            remainEles--;
            return key;
        }
    }

    @Override
    public Iterator<K> iterator() {
        return new HashMapIterator();
    }

    private static class Entry<K, V> {
        private K key = null;
        private V value = null;

        public Entry(K key, V value) {
            this.key = key;
            this.value = value;
        }
    }
}
