import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.Iterator;


public class DictionaryTest {
    // Do not modify this function. All your tests should use newDictionary() to generate the dictionary reference.
    public Dictionary<Integer,String> newDictionary() {
        return new LinkedListDictionary<Integer,String>();
    }

    // find tests
    @Test
    void testEmptyFind(){

        Dictionary<Integer,String> dict = newDictionary();

        assertNull(dict.find(3),"Incorrect empty find behavior");
    }
    @Test
    void testSingleFind(){

        Dictionary<Integer,String> dict = newDictionary();
        dict.insert(3,"three");

        assertEquals("three",dict.find(3),"Incorrect single element find behavior");
    }
    @Test
    void testManyFind(){

        Dictionary<Integer,String> dict = newDictionary();
        dict.insert(3,"three");
        dict.insert(4, "four");
        dict.insert(5, "five");

        assertEquals("three",dict.find(3),"Incorrect many element find behavior");
        assertEquals("four",dict.find(4),"Incorrect many element find behavior");
        assertEquals("five",dict.find(5),"Incorrect many element find behavior");
    }

    // insert test
    @Test
    void testEmptyInsert() {

        Dictionary<Integer,String> dict = newDictionary();
        assertNull(dict.find(3),"Incorrect empty find behavior");

        dict.insert(3, "three");
        assertEquals("three",dict.find(3),"Incorrect empty element find behavior");
    }
    // Single not needed, but I added it cuz HW wanted to
    @Test
    void testSingleInsert(){

        Dictionary<Integer,String> dict = newDictionary();
        dict.insert(3,"three");

        assertEquals("three",dict.find(3),"Incorrect empty element find behavior");
    }
    @Test
    void testMultiinsert() {
        Dictionary<Integer,String> dict = newDictionary();
        assertNull(dict.find(3),"Incorrect empty find behavior");

        dict.insert(3, "three");
        dict.insert(4, "four");
        dict.insert(5, "five");

        assertEquals("three",dict.find(3),"Incorrect single element find behavior");
        assertEquals("four",dict.find(4),"Incorrect single element find behavior");
        assertEquals("five",dict.find(5),"Incorrect single element find behavior");
    }

    // delete test
    @Test
    void testEmptyDelete () {
        Dictionary<Integer,String> dict = newDictionary();
        assertFalse(dict.delete(3), "Incorrect empty list delete behaviour");
    }
    @Test
    void testSingleDelete(){
        Dictionary<Integer,String> dict = newDictionary();
        dict.insert(3,"three");
        assertTrue(dict.delete(3));
        assertNull(dict.find(3),"Incorrect single element delete behavior");
    }
    @Test
    void testManyDelete(){

        Dictionary<Integer,String> dict = newDictionary();

        dict.insert(3,"three");
        dict.insert(4,"four");
        dict.insert(5,"five");

        for (int i = 3; i < 6; i++) {
            assertTrue(dict.delete(i));
        }

        assertNull(dict.find(3),"Incorrect multiple element delete behavior");
    }

    // Iterator tests
    @Test
    void testIteratorEmpty(){

        Dictionary<Integer,String> dict = newDictionary();
        Iterator<Integer> iter = dict.iterator();
        assertFalse(iter.hasNext(), "Incorrect emptied hasNext Iterator behavior");
    }
    @Test
    void testIteratorSingle(){

        Dictionary<Integer,String> dict = newDictionary();
        dict.insert(3,"three");
        Iterator<Integer> iter = dict.iterator();
        assertTrue(iter.hasNext(), "Incorrect single element hasNext Iterator behavior");
        assertEquals(3,iter.next(), "Incorrect single element iterator behavior");
        assertFalse(iter.hasNext(), "Incorrect emptied hasNext Iterator behavior");
    }
    @Test
    void testIteratorMany(){

        Dictionary<Integer,String> dict = newDictionary();
        dict.insert(3,"three");
        dict.insert(4,"four");
        dict.insert(5,"five");
        Iterator<Integer> iter = dict.iterator();
        assertTrue(iter.hasNext(), "Incorrect many element hasNext Iterator behavior");

        for (int i = 3; i < 6; i++) {
            assertEquals(i,iter.next(), "Incorrect many element iterator behavior");
        }
        assertFalse(iter.hasNext(), "Incorrect emptied hasNext Iterator behavior");
    }
}

