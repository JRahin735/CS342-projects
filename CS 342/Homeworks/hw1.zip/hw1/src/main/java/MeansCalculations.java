import java.lang.Math;
public class MeansCalculations {

    public static double arithmeticMean(double[] values){
        //TODO calculate the arithmetic mean of values and return the double.
        int size = values.length;
        double sum = 0.0;
        for (int i = 0; i < size; i++) {

            sum += values[i];
        }
        double result = sum/size;
        return result;
    }
    public static double geometricMean(double[] values){
        //TODO calculate the geometric mean of values and return the double.
        int size = values.length; // wtff
        double product = 1.0;
        for (int i = 0; i < size; i++) {

            product *= values[i];
        }

        double rev_size = 1.0/size;
        double result = Math.pow(product, rev_size);

        return result;

    }
    public static double weightedArithmeticMean(double[] values, double[] weights ){
        //TODO calculate the weighted arithmetic mean of values with weights and return the double.
        int v_size = values.length;
        int w_size = weights.length;

        if (v_size != w_size) {
            return 0;
        }

        double num = 0.0;
        double den = 0.0;

        for (int i = 0; i < v_size; i++) {

            num += (values[i] * weights[i]);
            den += weights[i];
        }

        double result = num/den;

        return result;
    }
    public static double[] movingGeometricMean(double[] values){
        //TODO calculate the array of geometric means for values. The array you return should have the same length as the input array
        int size = values.length;
        double[] result = new double[size];
        //double insert = 0.0;
        double product = 1.0;

        for (int i = 0; i < size; i++){

            double exp = 1.0/(i+1);
            product *= values[i];

            result[i] = Math.pow(product,exp);
        }

        return result;
    }



}
