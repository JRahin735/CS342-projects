import javafx.application.Application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;

import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;


import java.awt.*;

public class JavaFXTemplate extends Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	//feel free to remove the starter code from this method
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		primaryStage.setTitle("Rahin Jain Homework 3");

		Button b1 = new Button("button 1");
		Button b2 = new Button("button 2");

		b1.setShape(new Circle(1));
		b2.setShape(new Circle(1));
		b1.setStyle("-fx-background-color: #399952;");
		b2.setStyle("-fx-background-color: #399952;");


		VBox buttons = new VBox(20,b1, b2);


		TextField t1 = new TextField("enter text here then press button 1");
		TextField t2 = new TextField();
		t2.setEditable(false);


		BorderPane root = new BorderPane();
		root.setLeft(buttons);
		root.setCenter(t1);
		root.setRight(t2);

		root.setPadding(new Insets(50, 10, 20, 20));
		root.setStyle("-fx-background-color: #292e2b;");


		b1.setOnAction(e -> {
			String newText = t1.getText() + " : from the center text field!";
			t2.setText(newText);
			b1.setDisable(true);
			b1.setText("pressed");
		});

		b2.setOnAction(e -> {
			t1.clear();
			t2.setText("final string goes here");
			b1.setDisable(false);
			b1.setText("button one");
		});


		Scene scene = new Scene(root, 700,700);
		primaryStage.setScene(scene);
		primaryStage.show();
	}

}
