// @author: Rahin Jain

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;


public class Main extends Application {
	@Override
	public void start(Stage primaryStage) throws Exception {
		URL directory = new File("src/main/resources/Myfxml.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(directory);
		Scene scene = new Scene(root);
		scene.getStylesheets().add(new File("src/main/resources/styles/styleA.css").toURI().toURL().toExternalForm());
		primaryStage.setTitle("Rahin Jain - Homework 3");
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}
