// @author: Rahin Jain

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class MyController {

    @FXML
    private TextField textA;
    @FXML
    private TextField textB;
    @FXML
    private Button buttonA;
    @FXML
    private Button buttonB;

    @FXML
    private void buttonA(ActionEvent event) {

        String text = textA.getText();
        String newText = text + " : from the center text field!";
        textB.setText(newText);
        buttonA.setText("pressed");
    }

    @FXML
    private void buttonB(ActionEvent event) {

        textA.clear();
        textB.setText("final string goes here");
        buttonA.setDisable(false);
        buttonA.setText("button one");
    }
}
